#!/bin/bash
screen -S AmahiWorld -d -m supybot AmahiWorld.conf