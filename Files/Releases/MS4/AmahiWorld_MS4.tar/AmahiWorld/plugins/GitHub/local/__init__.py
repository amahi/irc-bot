# Stub so local is a module, used for third-party modules
