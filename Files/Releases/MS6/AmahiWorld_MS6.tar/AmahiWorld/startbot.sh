#!/bin/bash
cd /home/amahiworld
screen -S AmahiWorld -d -m supybot AmahiWorld.conf