The Amahi Bugs bugchecker
